## Contributing Code

1. Fork a repo from master branch.
2. Use the coding style outlined in the [bash coding style guide](https://github.com/easybash/bash-coding-style-guide).
3. Make pull requests to the development branch.
4. After code is being reviewed, the code will be merged to the master. Everything on master will be part of the next major release.

