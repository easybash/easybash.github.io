
# Ubuntu 16.04 (Xenial Xerus)

| Package name | Category | Default repository |
| --- | --- | --- | --- |
| MairaDB | Database | 10.0.38 |
| MySQL | Database | 5.7.29 |
| Redis | Database | 3.0.6 |
| Apache | Web Server | 2.4.18 |
| Nginx | Web Server | 1.10.3 |
| PHP-FPM | Language | - |
| Golang | Language | 1.6.2 |
| Node.js  |Language | 4.2.6 |
| Dart | Language | - |

Last modified: 2020/4/22