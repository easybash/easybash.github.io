
# Ubuntu 18.04 (Bionic Beaver)

| Package name | Category | Default repository |
| --- | --- | --- | --- |
| MairaDB | Database | 10.1.44 |
| MySQL | Database | 5.7.29 |
| Redis | Database | 4.0.9 |
| Apache | Web Server | 2.4.29 |
| Nginx | Web Server | 1.14 |
| PHP-FPM | Language | - |
| Golang | Language | 1.10.4 |
| Node.js  |Language | 8.10.0 |
| Dart | Language | - |

Last modified: 2020/4/22