
# Ubuntu 20.04 (Focal Fossa)

| Package name | Category | Default repository |
| --- | --- | --- | --- |
| MairaDB | Database | - |
| MySQL | Database | - |
| Redis | Database | - |
| Apache | Web Server | - |
| Nginx | Web Server | - |
| PHP-FPM | Language | - |
| Golang | Language | - |
| Node.js  |Language | - |
| Dart | Language | - |

Last modified: 2020/4/22